import json
import streamlit as st
import ollama

from shopnova_tools import (
    buscar_productos,
    consultar_stock_bajo,
    consultar_ventas,
    consultar_pedidos,
    consultar_ranking_productos,
)

# ============================================================
# CONFIGURACIÓN
# ============================================================

MODELO = "llama3.2"

st.set_page_config(
    page_title="ShopNova Assistant",
    page_icon="🛍️",
    layout="centered"
)

# ============================================================
# PROMPT DEL SISTEMA
# ============================================================

SYSTEM_PROMPT = """
Eres "ShopNova Assistant", el asistente de inteligencia artificial
para el personal administrativo de ShopNova, una tienda peruana
de comercio electrónico dedicada a ropa y moda sostenible.

OBJETIVO:
Ayudar a consultar información sobre productos, stock, ventas,
pedidos y desempeño comercial utilizando las herramientas disponibles.

REGLAS:

1. Responde siempre en español.
2. Mantén un tono profesional, claro y breve.
3. No inventes productos, tallas, precios, stock, ventas, pedidos
   ni cantidades.
4. Cuando una consulta necesite información de ShopNova, utiliza
   la herramienta correspondiente.
5. Basa las respuestas comerciales únicamente en los resultados
   proporcionados por las herramientas.
6. Si una consulta de ventas no indica un periodo, solicita las
   fechas antes de consultar.
7. Si existen varios resultados, preséntalos en una lista.
8. Si no existen resultados, indícalo claramente.
9. No reveles claves, contraseñas, tokens ni información sensible.
10. No modifiques información de ShopNova.
11. Responde primero con una conclusión corta.
"""

# ============================================================
# HERRAMIENTAS
# ============================================================

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "buscar_productos",
            "description": (
                "Busca prendas del catálogo de ShopNova utilizando "
                "nombre, categoría, talla y color."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "nombre": {
                        "type": "string",
                        "description": "Nombre o parte del nombre del producto."
                    },
                    "categoria": {
                        "type": "string",
                        "description": "Categoría del producto."
                    },
                    "talla": {
                        "type": "string",
                        "description": "Talla del producto."
                    },
                    "color": {
                        "type": "string",
                        "description": "Color del producto."
                    }
                }
            }
        }
    },

    {
        "type": "function",
        "function": {
            "name": "consultar_stock_bajo",
            "description": (
                "Obtiene las prendas cuyo stock es menor o igual "
                "al límite indicado."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "limite": {
                        "type": "integer",
                        "description": "Cantidad máxima de stock."
                    },
                    "categoria": {
                        "type": "string",
                        "description": "Categoría opcional."
                    }
                },
                "required": ["limite"]
            }
        }
    },

    {
        "type": "function",
        "function": {
            "name": "consultar_ventas",
            "description": (
                "Consulta las ventas registradas entre dos fechas "
                "y opcionalmente por categoría."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "fecha_inicio": {
                        "type": "string",
                        "description": "Fecha inicial en formato YYYY-MM-DD."
                    },
                    "fecha_fin": {
                        "type": "string",
                        "description": "Fecha final en formato YYYY-MM-DD."
                    },
                    "categoria": {
                        "type": "string",
                        "description": "Categoría opcional."
                    }
                },
                "required": ["fecha_inicio", "fecha_fin"]
            }
        }
    },

    {
        "type": "function",
        "function": {
            "name": "consultar_pedidos",
            "description": (
                "Consulta pedidos según su estado."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "estado": {
                        "type": "string",
                        "enum": [
                            "pendiente",
                            "pagado",
                            "preparando",
                            "enviado",
                            "entregado",
                            "cancelado"
                        ],
                        "description": "Estado del pedido."
                    },
                    "fecha_inicio": {
                        "type": "string",
                        "description": "Fecha inicial opcional."
                    },
                    "fecha_fin": {
                        "type": "string",
                        "description": "Fecha final opcional."
                    }
                },
                "required": ["estado"]
            }
        }
    },

    {
        "type": "function",
        "function": {
            "name": "consultar_ranking_productos",
            "description": (
                "Obtiene los productos más vendidos dentro de un periodo."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "fecha_inicio": {
                        "type": "string",
                        "description": "Fecha inicial en formato YYYY-MM-DD."
                    },
                    "fecha_fin": {
                        "type": "string",
                        "description": "Fecha final en formato YYYY-MM-DD."
                    },
                    "top_n": {
                        "type": "integer",
                        "description": "Cantidad de productos a mostrar."
                    }
                },
                "required": ["fecha_inicio", "fecha_fin"]
            }
        }
    }
]

# ============================================================
# MAPA DE FUNCIONES
# ============================================================

FUNCTIONS = {
    "buscar_productos": buscar_productos,
    "consultar_stock_bajo": consultar_stock_bajo,
    "consultar_ventas": consultar_ventas,
    "consultar_pedidos": consultar_pedidos,
    "consultar_ranking_productos": consultar_ranking_productos,
}


def ejecutar_herramienta(nombre, argumentos):
    funcion = FUNCTIONS.get(nombre)

    if not funcion:
        return {
            "error": f"Herramienta no disponible: {nombre}"
        }

    if argumentos is None:
        argumentos = {}

    try:
        if nombre == "consultar_stock_bajo":
            if "limite" not in argumentos:
                argumentos["limite"] = 5

        return funcion(**argumentos)

    except Exception as e:
        return {
            "error": f"Error al ejecutar {nombre}: {str(e)}"
        }


# ============================================================
# IA + FUNCTION CALLING
# ============================================================

def obtener_respuesta(pregunta, historial):

    mensajes = [
        {
            "role": "system",
            "content": SYSTEM_PROMPT
        }
    ]

    # Agregar historial
    for mensaje in historial:
        mensajes.append(mensaje)

    # Agregar pregunta actual
    mensajes.append({
        "role": "user",
        "content": pregunta
    })

    # Primera llamada al modelo
    respuesta = ollama.chat(
        model=MODELO,
        messages=mensajes,
        tools=TOOLS
    )

    # Agregamos respuesta del modelo
    mensajes.append(respuesta.message)

    # ========================================================
    # ¿EL MODELO SOLICITÓ UNA HERRAMIENTA?
    # ========================================================

    if respuesta.message.tool_calls:

        for llamada in respuesta.message.tool_calls:

            nombre = llamada.function.name
            argumentos = llamada.function.arguments

            resultado = ejecutar_herramienta(
                nombre,
                argumentos
            )

            # Devolver resultado de la herramienta al modelo
            mensajes.append({
                "role": "tool",
                "name": nombre,
                "content": json.dumps(
                    resultado,
                    ensure_ascii=False
                )
            })

        # Segunda llamada: generar respuesta final
        respuesta_final = ollama.chat(
            model=MODELO,
            messages=mensajes,
            tools=TOOLS
        )

        return respuesta_final.message.content

    # ========================================================
    # RESPUESTA NORMAL
    # ========================================================

    return respuesta.message.content


# ============================================================
# INTERFAZ
# ============================================================

st.title("🛍️ ShopNova Assistant")

st.caption(
    "Asistente de inteligencia artificial para consultas "
    "administrativas y comerciales"
)

st.info(
    "Puedes consultar productos, stock, ventas, pedidos "
    "y productos más vendidos utilizando lenguaje natural."
)

# ============================================================
# HISTORIAL
# ============================================================

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

for mensaje in st.session_state.chat_history:

    with st.chat_message(mensaje["role"]):

        st.markdown(mensaje["content"])


# ============================================================
# CONSULTAS RÁPIDAS
# ============================================================

st.markdown("### 💡 Consultas rápidas")

col1, col2, col3 = st.columns(3)

pregunta = None

if col1.button("📦 Stock bajo"):
    pregunta = "¿Qué prendas tienen 5 unidades o menos?"

if col2.button("🚚 Pedidos pendientes"):
    pregunta = "¿Cuántos pedidos están pendientes de envío?"

if col3.button("👕 Buscar casaca"):
    pregunta = "¿Hay casacas talla M de color azul?"


# ============================================================
# CHAT
# ============================================================

entrada = st.chat_input(
    "Escribe una pregunta sobre ShopNova..."
)

if entrada:
    pregunta = entrada


if pregunta:

    # Mostrar usuario
    st.session_state.chat_history.append({
        "role": "user",
        "content": pregunta
    })

    with st.chat_message("user"):
        st.markdown(pregunta)

    # Respuesta IA
    with st.chat_message("assistant"):

        with st.spinner("🤖 Analizando consulta..."):

            try:

                respuesta = obtener_respuesta(
                    pregunta,
                    st.session_state.chat_history[:-1]
                )

            except Exception as e:

                mensaje_error = str(e)

                if "connection" in mensaje_error.lower() or "refused" in mensaje_error.lower():
                    respuesta = (
                        "❌ No se pudo conectar con Ollama.\n\n"
                        "Verifica que Ollama esté abierto en tu computadora "
                        "(busca su ícono en la bandeja del sistema) e intenta de nuevo."
                    )
                else:
                    respuesta = (
                        "❌ Ocurrió un error al consultar la IA local:\n\n"
                        f"`{mensaje_error}`"
                    )

        st.markdown(respuesta)

    # Guardar respuesta
    st.session_state.chat_history.append({
        "role": "assistant",
        "content": respuesta
    })