PRODUCTOS = [
    {"nombre": "Polo Eco Basic", "categoria": "polos", "talla": "M", "color": "blanco", "stock": 3},
    {"nombre": "Casaca Denim Circular", "categoria": "casacas", "talla": "M", "color": "azul", "stock": 2},
    {"nombre": "Vestido Lino Aura", "categoria": "vestidos", "talla": "S", "color": "beige", "stock": 4},
    {"nombre": "Casaca EcoDenim", "categoria": "casacas", "talla": "M", "color": "azul", "stock": 8},
    {"nombre": "Polo Urban Green", "categoria": "polos", "talla": "L", "color": "verde", "stock": 12},
]

VENTAS = [
    {"fecha": "2026-09-01", "producto": "Polo Eco Basic", "categoria": "polos", "cantidad": 5, "total": 175},
    {"fecha": "2026-09-05", "producto": "Casaca Denim Circular", "categoria": "casacas", "cantidad": 4, "total": 280},
    {"fecha": "2026-09-10", "producto": "Vestido Lino Aura", "categoria": "vestidos", "cantidad": 6, "total": 420},
    {"fecha": "2026-09-15", "producto": "Polo Urban Green", "categoria": "polos", "cantidad": 3, "total": 120},
]

PEDIDOS = [
    {"id": 1001, "estado": "pendiente", "fecha": "2026-09-02"},
    {"id": 1002, "estado": "enviado", "fecha": "2026-09-04"},
    {"id": 1003, "estado": "pendiente", "fecha": "2026-09-08"},
    {"id": 1004, "estado": "entregado", "fecha": "2026-09-10"},
    {"id": 1005, "estado": "preparando", "fecha": "2026-09-14"},
]

def buscar_productos(nombre=None, categoria=None, talla=None, color=None):
    resultados = PRODUCTOS

    if nombre:
        resultados = [p for p in resultados if nombre.lower() in p["nombre"].lower()]
    if categoria:
        resultados = [p for p in resultados if p["categoria"].lower() == categoria.lower()]
    if talla:
        resultados = [p for p in resultados if p["talla"].lower() == talla.lower()]
    if color:
        resultados = [p for p in resultados if p["color"].lower() == color.lower()]

    return {"resultados": resultados}

def consultar_stock_bajo(limite=5, categoria=None):
    try:
        limite = int(limite)
    except (TypeError, ValueError):
        limite = 5

    resultados = [
        p for p in PRODUCTOS
        if p["stock"] <= limite
    ]

    if categoria:
        resultados = [
            p for p in resultados
            if p["categoria"].lower() == categoria.lower()
        ]

    return {
        "limite": limite,
        "categoria": categoria,
        "cantidad": len(resultados),
        "resultados": resultados
    }

def consultar_ventas(fecha_inicio, fecha_fin, categoria=None):
    resultados = [
        v for v in VENTAS
        if fecha_inicio <= v["fecha"] <= fecha_fin
    ]

    if categoria:
        resultados = [v for v in resultados if v["categoria"].lower() == categoria.lower()]

    cantidad = sum(v["cantidad"] for v in resultados)
    total = sum(v["total"] for v in resultados)

    return {
        "fecha_inicio": fecha_inicio,
        "fecha_fin": fecha_fin,
        "cantidad_unidades": cantidad,
        "total_ventas": total,
        "resultados": resultados,
    }

ESTADOS_VALIDOS = [
    "pendiente", "pagado", "preparando",
    "enviado", "entregado", "cancelado"
]

def consultar_pedidos(estado, fecha_inicio=None, fecha_fin=None):
    estado = estado.lower()

    if estado not in ESTADOS_VALIDOS:
        return {
            "error": f"Estado no válido: '{estado}'",
            "estados_validos": ESTADOS_VALIDOS
        }

    resultados = [p for p in PEDIDOS if p["estado"] == estado]

    if fecha_inicio:
        resultados = [p for p in resultados if p["fecha"] >= fecha_inicio]
    if fecha_fin:
        resultados = [p for p in resultados if p["fecha"] <= fecha_fin]

    return {"cantidad": len(resultados), "resultados": resultados}

def consultar_ranking_productos(fecha_inicio, fecha_fin, top_n=5):
    ventas = consultar_ventas(fecha_inicio, fecha_fin)["resultados"]

    ranking = {}
    for venta in ventas:
        nombre = venta["producto"]
        ranking[nombre] = ranking.get(nombre, 0) + venta["cantidad"]

    ordenado = sorted(
        ranking.items(),
        key=lambda item: item[1],
        reverse=True
    )[:top_n]

    return {
        "fecha_inicio": fecha_inicio,
        "fecha_fin": fecha_fin,
        "ranking": [
            {"producto": nombre, "unidades_vendidas": cantidad}
            for nombre, cantidad in ordenado
        ],
    }
