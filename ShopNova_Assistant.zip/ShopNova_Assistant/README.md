# ShopNova Assistant

Prototipo académico para la TA2 de Herramientas de Desarrollo de TIC.

## Tecnologías
- Python
- Streamlit
- OpenAI API
- Function Calling
- Datos simulados

## Instalación

1. Abrir esta carpeta en VS Code.
2. Crear un entorno virtual:

```bash
python -m venv .venv
```

3. Activarlo en Windows:

```bash
.venv\Scripts\activate
```

4. Instalar dependencias:

```bash
pip install -r requirements.txt
```

5. Copiar `.env.example` como `.env`.
6. Colocar la clave de OpenAI en `OPENAI_API_KEY`.

## Ejecución

```bash
streamlit run app.py
```

El navegador abrirá la interfaz de ShopNova Assistant.

## Consultas de prueba

- ¿Qué prendas tienen 5 unidades o menos?
- ¿Hay casacas talla M de color azul?
- ¿Cuántos pedidos están pendientes de envío?
- ¿Cuáles fueron las prendas más vendidas del 1 al 15 de septiembre?

Los datos son simulados y están en `shopnova_tools.py`.

## Módulo IoT (nodo simulado + broker EMQX)

Ver [`iot/README.md`](iot/README.md).
