# Módulo IoT – ShopNova

Incluye dos partes:

1. **Broker MQTT EMQX** con configuración completa y credenciales personalizadas (`emqx/`).
2. **Simulación del nodo IoT en Python** (`nodo_iot.py`) que publica telemetría del almacén.

## 1. Broker MQTT (EMQX)

Requiere Docker Desktop.

```bash
cd iot/emqx
docker compose up -d
```

| Elemento | Valor |
|---|---|
| Dashboard | http://localhost:18083 |
| Usuario dashboard | `shopnova_admin` |
| Contraseña dashboard | `ShopNova#Admin2026` |
| Puerto MQTT | `1883` |
| Usuario nodo IoT | `shopnova_nodo01` / `Sn0va#Iot2026` |
| Usuario monitor (superusuario) | `shopnova_monitor` / `M0nitor#Sn2026` |
| Acceso anónimo | Deshabilitado |

Los usuarios MQTT se cargan desde `emqx/auth/usuarios.csv`. Para agregar más, edita
ese archivo y ejecuta `docker compose down -v && docker compose up -d`,
o créalos desde el Dashboard en *Access Control → Authentication*.

## 2. Nodo IoT simulado

```bash
pip install -r requirements.txt
cd iot
python nodo_iot.py
```

Opciones:

- `--intervalo 2` envía cada 2 segundos (por defecto 5).
- `--sin-broker` solo imprime las lecturas, sin conectar a MQTT.

Las credenciales y el host se pueden cambiar en `.env` (`MQTT_HOST`, `MQTT_PORT`,
`MQTT_USER`, `MQTT_PASSWORD`, `NODO_ID`).

### Topics

| Topic | Contenido |
|---|---|
| `shopnova/almacen/nodo01/telemetria` | JSON con temperatura, humedad, luz y alerta |
| `shopnova/almacen/nodo01/estado` | `online` / `offline` (retenido, con Last Will) |

### Verificar con el Dashboard

En el Dashboard abre *Diagnose → WebSocket Client*, conéctate con
`shopnova_monitor` / `M0nitor#Sn2026` y suscríbete a `shopnova/almacen/#`.

Ejemplo de mensaje:

```json
{"nodo_id": "nodo01", "secuencia": 1, "timestamp": "2026-09-26T10:00:00+00:00",
 "temperatura_c": 22.15, "humedad_pct": 54.8, "luz_lux": 310, "alerta": false}
```
