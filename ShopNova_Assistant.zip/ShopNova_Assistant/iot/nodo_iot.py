"""
Simulación de un nodo IoT de ShopNova con Python.

El nodo representa un sensor ubicado en el almacén de ropa. Mide temperatura,
humedad y nivel de luz, y publica los datos por MQTT (broker EMQX) cada
INTERVALO segundos, de forma continua, hasta que se presione Ctrl+C.

Uso:
    python nodo_iot.py                 # publica al broker EMQX
    python nodo_iot.py --sin-broker    # solo imprime los datos (prueba local)
    python nodo_iot.py --intervalo 2   # cambia el intervalo de envío
"""

import argparse
import json
import os
import random
import signal
import sys
import time
from datetime import datetime, timezone

from dotenv import load_dotenv

# ============================================================
# CONFIGURACIÓN (se lee de ../.env; si no existe, usa valores por defecto)
# ============================================================
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

MQTT_HOST = os.getenv("MQTT_HOST", "localhost")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_USER = os.getenv("MQTT_USER", "shopnova_nodo01")
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "Sn0va#Iot2026")
NODO_ID = os.getenv("NODO_ID", "nodo01")

TOPIC_TELEMETRIA = f"shopnova/almacen/{NODO_ID}/telemetria"
TOPIC_ESTADO = f"shopnova/almacen/{NODO_ID}/estado"

corriendo = True  # bandera para detener el bucle de forma ordenada


# ============================================================
# SIMULACIÓN DEL SENSOR
# ============================================================
class SensorSimulado:
    """Genera lecturas realistas: cada valor varía poco respecto al anterior."""

    def __init__(self):
        self.temperatura = 22.0  # °C
        self.humedad = 55.0      # %
        self.luz = 300           # lux

    @staticmethod
    def _limitar(valor, minimo, maximo):
        return max(minimo, min(maximo, valor))

    def leer(self):
        self.temperatura = self._limitar(self.temperatura + random.uniform(-0.4, 0.4), 15, 35)
        self.humedad = self._limitar(self.humedad + random.uniform(-1.5, 1.5), 30, 90)
        self.luz = int(self._limitar(self.luz + random.uniform(-25, 25), 0, 800))
        return {
            "temperatura_c": round(self.temperatura, 2),
            "humedad_pct": round(self.humedad, 2),
            "luz_lux": self.luz,
        }


def construir_mensaje(nodo_id, lectura, secuencia):
    """Arma el payload JSON que se enviará al broker."""
    alerta = lectura["temperatura_c"] > 30 or lectura["humedad_pct"] > 80
    return {
        "nodo_id": nodo_id,
        "secuencia": secuencia,
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        **lectura,
        "alerta": alerta,
    }


# ============================================================
# MQTT
# ============================================================
def conectar_mqtt():
    """Crea el cliente MQTT, autentica con credenciales y define el LWT."""
    import paho.mqtt.client as mqtt

    cliente = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"shopnova-{NODO_ID}")
    cliente.username_pw_set(MQTT_USER, MQTT_PASSWORD)

    # Last Will: si el nodo se cae, el broker publica "offline" automáticamente
    cliente.will_set(TOPIC_ESTADO, "offline", qos=1, retain=True)

    def on_connect(client, userdata, flags, reason_code, properties):
        if reason_code == 0:
            print(f"[MQTT] Conectado a {MQTT_HOST}:{MQTT_PORT} como '{MQTT_USER}'")
            client.publish(TOPIC_ESTADO, "online", qos=1, retain=True)
        else:
            print(f"[MQTT] Conexión rechazada: {reason_code}")

    def on_disconnect(client, userdata, flags, reason_code, properties):
        print(f"[MQTT] Desconectado ({reason_code}). Reintentando...")

    cliente.on_connect = on_connect
    cliente.on_disconnect = on_disconnect
    cliente.reconnect_delay_set(min_delay=1, max_delay=30)  # reconexión automática

    cliente.connect(MQTT_HOST, MQTT_PORT, keepalive=30)
    cliente.loop_start()  # hilo en segundo plano para red y reconexión
    return cliente


# ============================================================
# PROGRAMA PRINCIPAL
# ============================================================
def detener(*_):
    global corriendo
    corriendo = False


def main():
    parser = argparse.ArgumentParser(description="Nodo IoT simulado de ShopNova")
    parser.add_argument("--intervalo", type=float, default=5, help="segundos entre envíos")
    parser.add_argument("--sin-broker", action="store_true", help="no conectar a MQTT, solo imprimir")
    args = parser.parse_args()

    signal.signal(signal.SIGINT, detener)   # Ctrl+C
    signal.signal(signal.SIGTERM, detener)

    sensor = SensorSimulado()
    cliente = None

    if not args.sin_broker:
        try:
            cliente = conectar_mqtt()
        except Exception as error:
            print(f"[ERROR] No se pudo conectar al broker: {error}")
            print("        Verifica que EMQX esté activo (docker compose up -d) "
                  "o usa --sin-broker para probar sin red.")
            sys.exit(1)

    print(f"Nodo '{NODO_ID}' iniciado. Presiona Ctrl+C para detener.\n")
    secuencia = 0

    while corriendo:
        secuencia += 1
        mensaje = construir_mensaje(NODO_ID, sensor.leer(), secuencia)
        payload = json.dumps(mensaje, ensure_ascii=False)

        if cliente:
            cliente.publish(TOPIC_TELEMETRIA, payload, qos=1)
        print(f"[{secuencia:04d}] {TOPIC_TELEMETRIA} -> {payload}")

        # Espera fraccionada para responder rápido a Ctrl+C
        fin = time.time() + args.intervalo
        while corriendo and time.time() < fin:
            time.sleep(0.1)

    # Cierre ordenado
    print("\nDeteniendo nodo...")
    if cliente:
        cliente.publish(TOPIC_ESTADO, "offline", qos=1, retain=True).wait_for_publish(timeout=3)
        cliente.loop_stop()
        cliente.disconnect()
    print("Nodo detenido correctamente.")


if __name__ == "__main__":
    main()
